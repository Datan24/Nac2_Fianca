package br.com.fiap.nac2.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nac2Application {

	public static void main(String[] args) {
		SpringApplication.run(Nac2Application.class, args);
	}
}
